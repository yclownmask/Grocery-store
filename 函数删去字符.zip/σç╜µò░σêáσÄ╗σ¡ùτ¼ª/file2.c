void enter_string(char str[80])
{
    gets(str);
}